# disAlexNet
## How to run it
```
python disAlexNet.py localhost:22222 localhost:22233 --imagenet_path=./data/ILSVRC2012 --task_index=0 --job_name=worker
--targed_accuracy={$} --Optimizer={$} --Batch_size={$} --Learning_rate={$} --Epoch={$}  --imagenet_path={$} --task_index={$} 
--job_name={$} 
```

