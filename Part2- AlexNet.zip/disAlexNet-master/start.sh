./start_experiment.sh Adam 0.98 20
#./start_experiment.sh Adam 0.99 20
#./start_experiment.sh SGD 0.9 1
#./start_experiment.sh SGD 0.9 2
#./start_experiment.sh SGD 0.9 3
#./start_experiment.sh SGD 0.9 4
#./start_experiment.sh SGD 0.9 5
#./start_experiment.sh SGD 0.9 6
