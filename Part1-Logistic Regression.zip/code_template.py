import tensorflow as tf

# define the command line flags that can be sent
tf.app.flags.DEFINE_integer("task_index", 0, "Index of task with in the job.")
tf.app.flags.DEFINE_string("job_name", "worker", "either worker or ps")
tf.app.flags.DEFINE_string("deploy_mode", "single", "either single or cluster")
tf.app.flags.DEFINE_integer("issync", 0, "Whether to adopt Distributed Synchronization Mode, 1: sync, 0: async")
tf.app.flags.DEFINE_float('lr', 0.00003, 'Initial learning rate')
tf.app.flags.DEFINE_integer('steps_to_validate', 1000, 'Step to validate and print loss')
FLAGS = tf.app.flags.FLAGS

# Hyperparameters
learning_rate = FLAGS.lr
steps_to_validate = FLAGS.steps_to_validate

tf.logging.set_verbosity(tf.logging.DEBUG)

clusterSpec_single = tf.train.ClusterSpec({
    "worker" : [
        "localhost:2222"
    ]
})

clusterSpec_cluster = tf.train.ClusterSpec({
    "ps" : [
        "hp028.utah.cloudlab.us:2222"
    ],
    "worker" : [
        "hp028.utah.cloudlab.us:2222",
        "hp033.utah.cloudlab.us:2222"
    ]
})

clusterSpec_cluster2 = tf.train.ClusterSpec({
    "ps" : [
        "hp028.utah.cloudlab.us:2222"
    ],
    "worker" : [
        "hp028.utah.cloudlab.us:2222",
        "hp033.utah.cloudlab.us:2222",
        "hp023.utah.cloudlab.us:2222",
        "hp025.utah.cloudlab.us:2222"
    ]
})

clusterSpec = {
    "single": clusterSpec_single,
    "cluster": clusterSpec_cluster,
    "cluster2": clusterSpec_cluster2
}

clusterinfo = clusterSpec[FLAGS.deploy_mode]
server = tf.train.Server(clusterinfo, job_name=FLAGS.job_name, task_index=FLAGS.task_index)

if FLAGS.job_name == "ps":
    server.join()
elif FLAGS.job_name == "worker":
    #put your code here

